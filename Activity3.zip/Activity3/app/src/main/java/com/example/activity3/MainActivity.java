package com.example.activity3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText idField;
    EditText nameField;
    EditText phoneNumberField;
    TextView outputField;
    Button addContactButton;
    Button searchContactButton;
    Button deleteContactButton;
    Button updateContactButton;
    Button showAllButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        idField = findViewById(R.id.id);
        nameField = findViewById(R.id.name);
        phoneNumberField = findViewById(R.id.phone_number);
        outputField = findViewById(R.id.output);
        addContactButton = findViewById(R.id.add_contact);
        searchContactButton = findViewById(R.id.search_contact);
        deleteContactButton = findViewById(R.id.delete_contact);
        updateContactButton = findViewById(R.id.update_contact);
        showAllButton = findViewById(R.id.show_all);

        addContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameStr = nameField.getText().toString();
                String phoneStr = phoneNumberField.getText().toString();
                Contact newContact = new Contact(nameStr, phoneStr);
                db.addContact(newContact);
                outputField.setText("Added new contact: " + nameStr);
            }
        });

        searchContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameStr = nameField.getText().toString();
                Contact contact = db.getContact(nameStr);
                if (contact != null) {
                    outputField.setText("Found contact: " + contact.getName() + ", " + contact.getPhoneNumber());
                } else {
                    outputField.setText("No contact found with name: " + nameStr);
                }
            }
        });

        deleteContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(idField.getText().toString());
                db.deleteContact(new Contact(id, "", ""));
                outputField.setText("Deleted contact with ID: " + id);
            }
        });

        updateContactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = Integer.parseInt(idField.getText().toString());
                String nameStr = nameField.getText().toString();
                String phoneStr = phoneNumberField.getText().toString();
                db.updateContact(new Contact(id, nameStr, phoneStr));
                outputField.setText("Updated contact with ID: " + id);
            }
        });

        showAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                List<Contact> contacts = db.getAllContacts();
                StringBuilder outputStr = new StringBuilder();
                for (Contact contact : contacts) {
                    outputStr.append("ID: ").append(contact.getID())
                            .append(", Name: ").append(contact.getName())
                            .append(", Phone: ").append(contact.getPhoneNumber())
                            .append("\n");
                }
                outputField.setText(outputStr.toString());
            }
        });
    }
}
